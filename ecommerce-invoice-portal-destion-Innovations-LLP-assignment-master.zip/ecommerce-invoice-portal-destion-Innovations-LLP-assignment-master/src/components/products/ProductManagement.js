import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import {
  Container,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Button,
  TextField,
  Box,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
} from '@mui/material';
import {
  setProducts,
  addProduct,
  updateProduct,
  deleteProduct,
  setFilters,
} from '../../store/slices/productSlice';

const ProductManagement = () => {
  const dispatch = useDispatch();
  const { products, filters } = useSelector((state) => state.products);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    regularPrice: '',
    dealPrice: '',
    store: '',
  });

  // Mock stores data - in a real app, this would come from an API
  const stores = [
    { id: 1, name: 'Store A' },
    { id: 2, name: 'Store B' },
    { id: 3, name: 'Store C' },
  ];

  useEffect(() => {
    // In a real app, fetch products from API
    const mockProducts = [
      {
        id: 1,
        name: 'Product 1',
        description: 'Description 1',
        regularPrice: 100,
        dealPrice: 80,
        store: 'Store A',
      },
      // Add more mock data as needed
    ];
    dispatch(setProducts(mockProducts));
  }, [dispatch]);

  const handleOpenDialog = (product = null) => {
    if (product) {
      setEditingProduct(product);
      setFormData(product);
    } else {
      setEditingProduct(null);
      setFormData({
        name: '',
        description: '',
        regularPrice: '',
        dealPrice: '',
        store: '',
      });
    }
    setDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setDialogOpen(false);
    setEditingProduct(null);
  };

  const handleSubmit = () => {
    if (editingProduct) {
      dispatch(updateProduct({ ...formData, id: editingProduct.id }));
    } else {
      dispatch(addProduct({ ...formData, id: Date.now() }));
    }
    handleCloseDialog();
  };

  const handleDelete = (productId) => {
    if (window.confirm('Are you sure you want to delete this product?')) {
      dispatch(deleteProduct(productId));
    }
  };

  const handleFilterChange = (e) => {
    dispatch(setFilters({ [e.target.name]: e.target.value }));
  };

  const filteredProducts = products.filter((product) => {
    const matchesStore = !filters.store || product.store === filters.store;
    const matchesSearch = !filters.searchQuery ||
      product.name.toLowerCase().includes(filters.searchQuery.toLowerCase()) ||
      product.description.toLowerCase().includes(filters.searchQuery.toLowerCase());
    return matchesStore && matchesSearch;
  });

  return (
    <Container maxWidth="lg" sx={{ mt: 4 }}>
      <Box sx={{ mb: 4, display: 'flex', gap: 2 }}>
        <TextField
          label="Search Products"
          name="searchQuery"
          value={filters.searchQuery}
          onChange={handleFilterChange}
        />
        <FormControl sx={{ minWidth: 200 }}>
          <InputLabel>Filter by Store</InputLabel>
          <Select
            name="store"
            value={filters.store || ''}
            onChange={handleFilterChange}
            label="Filter by Store"
          >
            <MenuItem value="">All Stores</MenuItem>
            {stores.map((store) => (
              <MenuItem key={store.id} value={store.name}>
                {store.name}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
        <Button
          variant="contained"
          color="primary"
          onClick={() => handleOpenDialog()}
        >
          Add Product
        </Button>
      </Box>

      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Name</TableCell>
              <TableCell>Description</TableCell>
              <TableCell>Store</TableCell>
              <TableCell>Regular Price</TableCell>
              <TableCell>Deal Price</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {filteredProducts.map((product) => (
              <TableRow key={product.id}>
                <TableCell>{product.name}</TableCell>
                <TableCell>{product.description}</TableCell>
                <TableCell>{product.store}</TableCell>
                <TableCell>${product.regularPrice}</TableCell>
                <TableCell>${product.dealPrice}</TableCell>
                <TableCell>
                  <Button
                    variant="outlined"
                    size="small"
                    onClick={() => handleOpenDialog(product)}
                    sx={{ mr: 1 }}
                  >
                    Edit
                  </Button>
                  <Button
                    variant="outlined"
                    color="error"
                    size="small"
                    onClick={() => handleDelete(product.id)}
                  >
                    Delete
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      <Dialog open={dialogOpen} onClose={handleCloseDialog}>
        <DialogTitle>
          {editingProduct ? 'Edit Product' : 'Add New Product'}
        </DialogTitle>
        <DialogContent>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, pt: 2 }}>
            <TextField
              label="Product Name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              fullWidth
            />
            <TextField
              label="Description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              fullWidth
              multiline
              rows={3}
            />
            <FormControl fullWidth>
              <InputLabel>Store</InputLabel>
              <Select
                value={formData.store}
                onChange={(e) => setFormData({ ...formData, store: e.target.value })}
                label="Store"
              >
                {stores.map((store) => (
                  <MenuItem key={store.id} value={store.name}>
                    {store.name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            <TextField
              label="Regular Price"
              type="number"
              value={formData.regularPrice}
              onChange={(e) => setFormData({ ...formData, regularPrice: e.target.value })}
              fullWidth
            />
            <TextField
              label="Deal Price"
              type="number"
              value={formData.dealPrice}
              onChange={(e) => setFormData({ ...formData, dealPrice: e.target.value })}
              fullWidth
            />
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog}>Cancel</Button>
          <Button onClick={handleSubmit} variant="contained" color="primary">
            {editingProduct ? 'Save Changes' : 'Add Product'}
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
};

export default ProductManagement;
