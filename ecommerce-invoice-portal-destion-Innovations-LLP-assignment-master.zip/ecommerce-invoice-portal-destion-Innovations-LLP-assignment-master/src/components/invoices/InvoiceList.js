import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import {
  Container,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Button,
  TextField,
  Box,
} from '@mui/material';
import { DatePicker } from '@mui/x-date-pickers';
import moment from 'moment';
import { setInvoices, setFilters } from '../../store/slices/invoiceSlice';
import jsPDF from 'jspdf';
import 'jspdf-autotable';

const InvoiceList = () => {
  const dispatch = useDispatch();
  const { invoices, filters } = useSelector((state) => state.invoices);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    // In a real app, fetch invoices from API
    const mockInvoices = [
      {
        id: 1,
        orderId: 'ORD001',
        date: '2025-03-07',
        storeName: 'Store A',
        items: [
          {
            name: 'Product 1',
            quantity: 2,
            regularPrice: 100,
            dealPrice: 80,
            tax: 10,
          }
        ],
      },
      // Add more mock data as needed
    ];
    dispatch(setInvoices(mockInvoices));
  }, [dispatch]);

  const handleDateChange = (type) => (date) => {
    dispatch(setFilters({ [type]: date }));
  };

  const calculateTotal = (items) => {
    return items.reduce((acc, item) => {
      const itemTotal = item.quantity * item.dealPrice;
      const itemTax = (itemTotal * item.tax) / 100;
      return {
        subtotal: acc.subtotal + itemTotal,
        tax: acc.tax + itemTax,
        total: acc.total + itemTotal + itemTax,
      };
    }, { subtotal: 0, tax: 0, total: 0 });
  };

  const generatePDF = (invoice) => {
    const doc = new jsPDF();
    const totals = calculateTotal(invoice.items);

    doc.text(`Invoice #${invoice.orderId}`, 20, 20);
    doc.text(`Store: ${invoice.storeName}`, 20, 30);
    doc.text(`Date: ${invoice.date}`, 20, 40);

    const tableData = invoice.items.map(item => [
      item.name,
      item.quantity,
      item.regularPrice,
      item.dealPrice,
      item.tax + '%',
      (item.quantity * item.dealPrice).toFixed(2)
    ]);

    doc.autoTable({
      startY: 50,
      head: [['Item', 'Qty', 'Regular', 'Deal', 'Tax', 'Total']],
      body: tableData,
    });

    const finalY = doc.lastAutoTable.finalY || 50;
    doc.text(`Subtotal: $${totals.subtotal.toFixed(2)}`, 20, finalY + 20);
    doc.text(`Tax: $${totals.tax.toFixed(2)}`, 20, finalY + 30);
    doc.text(`Total: $${totals.total.toFixed(2)}`, 20, finalY + 40);

    doc.save(`invoice-${invoice.orderId}.pdf`);
  };

  const filteredInvoices = invoices.filter(invoice => {
    const matchesDate = (!filters.startDate || moment(invoice.date).isSameOrAfter(filters.startDate)) &&
      (!filters.endDate || moment(invoice.date).isSameOrBefore(filters.endDate));
    const matchesSearch = invoice.storeName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      invoice.orderId.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesDate && matchesSearch;
  });

  return (
    <Container maxWidth="lg" sx={{ mt: 4 }}>
      <Box sx={{ mb: 4, display: 'flex', gap: 2 }}>
        <TextField
          label="Search"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        <DatePicker
          label="Start Date"
          value={filters.startDate}
          onChange={handleDateChange('startDate')}
        />
        <DatePicker
          label="End Date"
          value={filters.endDate}
          onChange={handleDateChange('endDate')}
        />
      </Box>

      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Order ID</TableCell>
              <TableCell>Store</TableCell>
              <TableCell>Date</TableCell>
              <TableCell>Subtotal</TableCell>
              <TableCell>Tax</TableCell>
              <TableCell>Total</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {filteredInvoices.map((invoice) => {
              const totals = calculateTotal(invoice.items);
              return (
                <TableRow key={invoice.id}>
                  <TableCell>{invoice.orderId}</TableCell>
                  <TableCell>{invoice.storeName}</TableCell>
                  <TableCell>{invoice.date}</TableCell>
                  <TableCell>${totals.subtotal.toFixed(2)}</TableCell>
                  <TableCell>${totals.tax.toFixed(2)}</TableCell>
                  <TableCell>${totals.total.toFixed(2)}</TableCell>
                  <TableCell>
                    <Button
                      variant="contained"
                      size="small"
                      onClick={() => generatePDF(invoice)}
                    >
                      Download PDF
                    </Button>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </TableContainer>
    </Container>
  );
};

export default InvoiceList;
